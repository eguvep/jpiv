# SIGconf

This is the configuration file for the SIG (synthetic image generator). The SIG was a EUROPIV II Project by Bertrand Lecordier, Jose Nogueira, and Jerry Westerweel. More information at:

http://www.meol.cnrs.fr/LML/EuroPIV2/SIG/doc/SIG_Main.htm

You can use the JPIV Skripts »generate_synthetic_images_2d.jsc« and »generate_synthetic_images_3d« for conveniently generating synthetic images via SIG. Please note, that the SIG is only available for Linux!
