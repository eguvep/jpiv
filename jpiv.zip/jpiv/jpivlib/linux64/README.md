# SIG

This is the Europiv II Synthetic Image Generator binary for Linux. More information at:

http://www.meol.cnrs.fr/LML/EuroPIV2/SIG/doc/SIG_Main.htm

Call this programme conveniently via one of the Synthetic image generation scripts (Script drop down menu in JPIV).
