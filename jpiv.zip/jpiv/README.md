# Distribution Directory

The content of this directory will be zipped and distributed.

Launch JPIV in your terminal by executing:

`java -jar JPIV.jar`

More information on: https://eguvep.github.io/jpiv/

