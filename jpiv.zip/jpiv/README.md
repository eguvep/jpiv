Start JPIV by executing:

java -jar jpiv.jar

More information on: https://eguvep.github.io/jpiv/

